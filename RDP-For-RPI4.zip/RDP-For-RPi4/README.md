# RDP-For-RPI4
git clone https://github.com/jamieduk/RDP-For-RPI4.git
# Then UNZIP
unzip *.zip
# Forum Link
# https://jnet.forumotion.com/t1767-rdp-for-rpi4#2729
#
# Site Link jnet.sytes.net

Manual Install

goto
# Forum Link
# https://jnet.forumotion.com/t1767-rdp-for-rpi4#2729
#
